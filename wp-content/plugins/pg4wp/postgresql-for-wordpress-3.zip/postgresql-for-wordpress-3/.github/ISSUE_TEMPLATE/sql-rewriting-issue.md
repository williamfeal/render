---
name: SQL Rewriting Issue
about: This is used for filing bugs or problems with PG4WP
title: ''
labels: ''
assignees: ''

---

WP Version:
PG4WP Version: 

Error: 
```

```

RAW SQL
```

```

Expected Rewritten SQL
```

```

Actual Rewritten SQL
```

```
